This folder contains files associated with CALET data analysis used for 
separation of pulsar from DM model. 

We considered only the background parameters since the pulsar and DM models are 
independent of each other.

The background parameters are (in DM_pul_modelB_PCA.csv file)

C_s/C_e = ratio of secondary to primary
phi     =  solar modulation potential in GeV
Eg      = break energy 
de      = change in power-law index at Eg
Ed      = background cut-off energy
s       = smoothness parameter
Ce      = normalization of primary electron spectrum 
ge      = background primary electron injection index before the break energy (Eg)


1, 0 are label where 1 is used for DM and vice versa




More details about the modeling and ci square separation methods can be found in our paper (https://www.worldscientific.com/doi/abs/10.1142/S0218271819500354)
