#!/usr/bin/python

import math 
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd 
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA



df = pd.read_csv('DM_pul_ModelB_PCA.csv')
#print df.head(3)

# shuffle the data points so that pulsar and DM classes get mixed 

df_mix=df.sample(frac=1).reset_index(drop=True)
#print df_mix.head(5)


X = df_mix.iloc[:,0:8]

#print X.head(3)

Y = df_mix.iloc[:,8:9].values.tolist()
print type(Y)
print Y[50:60]


yl= [int(target) for [target] in Y]
print yl[50:60]


#Yl=Y[:,0].values.tolist()
#print Y.head(3)
#print len(Yl)
#print Yl[50:55]

print np.shape(X)
#print np.shape(Y)



scaler = StandardScaler() # standardized feature by removing mean and scaled to unit variance 
scaler.fit(X)

X_scaled = scaler.transform(X)


#print "after scaling", X_scaled.min(axis=0)




pca = PCA(n_components=2) # instantiate the PCA and keep the first n components
pca.fit(X_scaled)
# now transform 

x_pca=pca.transform(X_scaled)

print np.shape(x_pca)


#+++++++++++++++++++++++++++++
#+ plot the pcs
#+++++++++++++++++++++++++++++

#fig=plt.figure(figsize=(6,4))


#p=plt.scatter(x_pca[:,0],x_pca[:,1],s=40) 



Xax=x_pca[:,0]
Yax=x_pca[:,1]
labels=yl
#labels=['Malignant','Benign']
cdict={0:'green',1:'red'}
labl={0:'Pulsar',1:'DM'}
marker={0:'*',1:'o'}
alpha={0:.3, 1:.2}
fig,ax=plt.subplots(figsize=(7,5))
fig.patch.set_facecolor('white')
for l in np.unique(labels):
	ix=np.where(labels==l)
	ax.scatter(Xax[ix],Yax[ix],c=cdict[l],label=labl[l],s=10,marker=marker[l],alpha=alpha[l])




plt.xlabel("First Principal Component",fontsize=14)
plt.ylabel("Second Principal Component",fontsize=14)

plt.legend(fontsize=15)


plt.show() 

'''

#+++++++++++++++++++++++++++++++++++++++++
#+ correlation plots 
#+++++++++++++++++++++++++++++++++++++++++
DMdf = pd.read_csv('DMModelB_DMfitbkginfo.csv')

print DMdf.head(3)

DMdf.columns = ['Ratio','Solar Mod','Break Energy','Index Change','BKG_cut','smoothness','Norm','Index']

print DMdf.head(3)


DMfeatures = DMdf.values.tolist()

print DMfeatures [50:60]

sDM = sns.heatmap(DMdf.corr(),cmap='coolwarm')
sDM.set_yticklabels(sDM.get_yticklabels(),rotation=30,fontsize=9)
sDM.set_xticklabels(sDM.get_xticklabels(),rotation=30,fontsize=9)
plt.title('DM Model')
plt.show()# super happy to complete this project




pulsardf = pd.read_csv('DMModelB_pulfitbkginfo.csv')

print pulsardf.head(3)

pulsardf.columns = ['Ratio','Solar Mod','Break Energy','Index Change','BKG_cut','smoothness','Norm','Index']

print DMdf.head(3)


spulsar = sns.heatmap(pulsardf.corr(),cmap='coolwarm')
spulsar.set_yticklabels(spulsar.get_yticklabels(),rotation=30,fontsize=9)
spulsar.set_xticklabels(spulsar.get_xticklabels(),rotation=30,fontsize=9)
plt.title('Pulsar Model')
plt.show()# super happy to complete this project
'''
